import json
from pathlib import Path
from collections import Counter
counts=Counter();greetings=[];ratios=[]
for p in sorted(Path('mpskill-trainer/dist/data/scenarios').glob('scenario-*.json')):
 s=json.loads(p.read_text(encoding='utf8'))
 assert len(s['questions'])==15
 for q in s['questions']:
  lengths=[len(o['text']) for o in q['options']];correct=lengths[q['correct_index']]
  assert lengths.count(correct)==1,(s['id'],q['id'],'tied length')
  counts[['shortest','middle','longest'][sorted(lengths).index(correct)]]+=1
  ratios.append(max(lengths)/min(lengths))
  assert len(set(o['text'] for o in q['options']))==3
 first=s['questions'][0];assert all(o['text'].startswith('Здравствуйте!') for o in first['options']);greetings.append(s['id'])
assert counts=={'shortest':25,'middle':25,'longest':25},counts
report=dict(questions=75,answers=225,correct_answer_length_rank=dict(counts),first_question_greetings='all three options in all five stories',correct_position_order='shuffled balanced 25 per position',note='Length and structure checks do not prove editorial quality or learning effectiveness.')
Path('mpskill-trainer/editorial/answer-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('PASS: correct answer shortest/middle/longest = 25/25/25; all introductory answers have greetings; no tied correct lengths')
